<script setup>
import { ref, computed, watch, onMounted, onBeforeUnmount } from 'vue'
import * as duckdb from '@duckdb/duckdb-wasm'

const initMessage = ref('DuckDB 正在启动...')
const errorMessage = ref('')
const dbReady = ref(false)
const isLoadingFile = ref(false)
const fileStats = ref(null)
const previewColumns = ref([])
const previewRows = ref([])
const summary = ref(null)
const pageSize = ref(50)
const pageSizeOptions = [25, 50, 100, 250]
const currentPage = ref(1)

const duckDbInstance = ref(null)
const duckDbConnection = ref(null)
const duckDbWorker = ref(null)

const formatBytes = size => {
  if (size === 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  const i = Math.floor(Math.log(size) / Math.log(1024))
  return `${(size / 1024 ** i).toFixed(2)} ${units[i]}`
}

const formatMs = ms => `${ms.toFixed(0)} ms`

const extensionRepository = ref('')

const configureExtensionRepository = bundle => {
  if (typeof window === 'undefined') return
  const version = duckdb.PACKAGE_VERSION || 'v1.0.0'
  const bundleUsesEH = bundle.mainModule?.includes('-eh')
  const variantFolder = bundleUsesEH ? 'wasm_eh' : 'wasm_mvp'
  const localRepo = new URL(`/duckdb-extensions/${version}/${variantFolder}/`, window.location.origin).href
  extensionRepository.value = localRepo
  globalThis.DUCKDB_EXTENSION_REPOSITORY = localRepo
}

const initDuckDB = async () => {
  try {
    initMessage.value = '寻找最佳 DuckDB-wasm 包...'
    const bundles = duckdb.getJsDelivrBundles()
    const bundle = await duckdb.selectBundle(bundles)
    configureExtensionRepository(bundle)

    initMessage.value = '启动 DuckDB worker...'
    const worker = await duckdb.createWorker(bundle.mainWorker)
    duckDbWorker.value = worker

    initMessage.value = '实例化 DuckDB...'
    const logger = new duckdb.ConsoleLogger()
    const db = new duckdb.AsyncDuckDB(logger, worker)
    await db.instantiate(bundle.mainModule, bundle.pthreadWorker)
    duckDbInstance.value = db

    initMessage.value = '创建连接...'
    const conn = await db.connect()
    duckDbConnection.value = conn

    initMessage.value = 'DuckDB 已就绪，可以加载本地 Parquet 文件'
    dbReady.value = true
  } catch (err) {
    console.error(err)
    errorMessage.value = err.message ?? 'DuckDB 初始化失败'
    initMessage.value = '初始化失败'
  }
}

const teardownDuckDB = async () => {
  try {
    await duckDbConnection.value?.close()
  } catch (err) {
    console.warn('关闭连接失败', err)
  }

  try {
    await duckDbInstance.value?.terminate?.()
  } catch (_) {
    /* noop */
  }

  try {
    duckDbWorker.value?.terminate()
  } catch (_) {
    /* noop */
  }
}

const arrowToRows = table => {
  const columns = []
  for (let i = 0; i < table.schema.fields.length; i += 1) {
    columns.push({
      name: table.schema.fields[i].name,
      vector: table.getChildAt(i),
    })
  }

  const rowCount = table.numRows ?? table.length ?? 0
  const rows = []
  for (let rowIndex = 0; rowIndex < rowCount; rowIndex += 1) {
    const row = {}
    for (const column of columns) {
      row[column.name] = column.vector?.get(rowIndex) ?? null
    }
    rows.push(row)
  }

  return {
    columns: columns.map(col => col.name),
    rows,
  }
}

const runPreviewQueries = async () => {
  const conn = duckDbConnection.value
  const rowCountTable = await conn.query('SELECT COUNT(*) AS row_count FROM parquet_data')
  const rowCounts = arrowToRows(rowCountTable)
  const rowCountValue = rowCounts.rows[0]?.row_count ?? 0

  const columnInfo = await conn.query("PRAGMA table_info('parquet_data')")
  const columnMeta = arrowToRows(columnInfo)

  summary.value = {
    rows: rowCountValue,
    columns: columnMeta.rows.length,
  }
  await fetchPageData()
}

const fetchPageData = async () => {
  if (!duckDbConnection.value || !summary.value) return
  const conn = duckDbConnection.value
  const size = pageSize.value
  const offset = (currentPage.value - 1) * size
  const previewTable = await conn.query(`SELECT * FROM parquet_data LIMIT ${size} OFFSET ${offset}`)
  const { columns, rows } = arrowToRows(previewTable)
  previewColumns.value = columns
  previewRows.value = rows
}

const totalPages = computed(() => {
  if (!summary.value?.rows) return 1
  return Math.max(1, Math.ceil(summary.value.rows / pageSize.value))
})

const goToPreviousPage = async () => {
  if (currentPage.value <= 1) return
  currentPage.value -= 1
  await fetchPageData()
}

const goToNextPage = async () => {
  if (currentPage.value >= totalPages.value) return
  currentPage.value += 1
  await fetchPageData()
}

watch(pageSize, async () => {
  if (!summary.value) return
  currentPage.value = 1
  await fetchPageData()
})

const handleParquetLoad = async file => {
  if (!duckDbInstance.value || !duckDbConnection.value) return
  isLoadingFile.value = true
  errorMessage.value = ''
  currentPage.value = 1

  const virtualFileName = `local/${Date.now()}-${file.name}`
  const startTime = performance.now()

  try {
    await duckDbInstance.value.registerFileHandle(
      virtualFileName,
      file,
      duckdb.DuckDBDataProtocol.BROWSER_FILEREADER,
      true,
    )

    const conn = duckDbConnection.value
    await conn.query('DROP TABLE IF EXISTS parquet_data')
    await conn.query(`
      CREATE TABLE parquet_data AS
      SELECT * FROM read_parquet('${virtualFileName}')
    `)

    const elapsed = performance.now() - startTime
    fileStats.value = {
      name: file.name,
      size: formatBytes(file.size),
      elapsed: formatMs(elapsed),
    }

    await runPreviewQueries()
  } catch (err) {
    console.error(err)
    errorMessage.value = err.message ?? '加载 parquet 失败'
  } finally {
    isLoadingFile.value = false
  }
}

const handleFileInput = async event => {
  const [file] = event.target.files
  event.target.value = ''
  if (file) {
    await handleParquetLoad(file)
  }
}

const handleDrop = async event => {
  event.preventDefault()
  if (!dbReady.value || isLoadingFile.value) return
  const file = event.dataTransfer.files?.[0]
  if (file) {
    await handleParquetLoad(file)
  }
}

const handleDragOver = event => {
  event.preventDefault()
}

onMounted(() => {
  initDuckDB()
})

onBeforeUnmount(() => {
  teardownDuckDB()
})
</script>

<template>
  <main class="page">
    <header>
      <h1>DuckDB-wasm Parquet 加载演示</h1>
      <p>支持浏览器内直接加载 1GB+ 的 Parquet 文件，并即时查询预览。</p>
    </header>

    <section class="status-card">
      <div class="status-row">
        <span class="label">数据库状态</span>
        <span :class="['badge', dbReady ? 'ok' : 'pending']">{{ initMessage }}</span>
      </div>
      <p v-if="errorMessage" class="error">{{ errorMessage }}</p>
      <p v-if="extensionRepository" class="hint">
        扩展仓库: <code>{{ extensionRepository }}</code>
      </p>
    </section>

    <section class="uploader" :class="{ disabled: !dbReady }">
      <label class="drop-area" @dragover="handleDragOver" @drop="handleDrop">
        <input
          type="file"
          accept=".parquet"
          :disabled="!dbReady || isLoadingFile"
          @change="handleFileInput"
        />
        <div class="drop-content">
          <strong v-if="dbReady">拖拽或选择本地 1GB Parquet 文件</strong>
          <strong v-else>等待 DuckDB 初始化...</strong>
          <span>{{ isLoadingFile ? '正在加载...' : '仅在浏览器内处理，无需上传' }}</span>
        </div>
      </label>
    </section>

    <section v-if="fileStats" class="stats">
      <h2>当前文件</h2>
      <ul>
        <li><span>名称</span><strong>{{ fileStats.name }}</strong></li>
        <li><span>大小</span><strong>{{ fileStats.size }}</strong></li>
        <li><span>加载耗时</span><strong>{{ fileStats.elapsed }}</strong></li>
      </ul>
    </section>

    <section v-if="summary" class="stats">
      <h2>DuckDB 表统计</h2>
      <ul>
        <li><span>行数</span><strong>{{ summary.rows.toLocaleString() }}</strong></li>
        <li><span>列数</span><strong>{{ summary.columns }}</strong></li>
      </ul>
    </section>

    <section v-if="previewRows.length" class="result">
      <h2>数据预览 (前 50 行)</h2>
      <div class="pagination">
        <div class="page-controls">
          <button @click="goToPreviousPage" :disabled="currentPage === 1">上一页</button>
          <span>第 {{ currentPage }} / {{ totalPages }} 页</span>
          <button @click="goToNextPage" :disabled="currentPage >= totalPages">下一页</button>
        </div>
        <label>
          每页
          <select v-model.number="pageSize">
            <option v-for="size in pageSizeOptions" :key="size" :value="size">{{ size }}</option>
          </select>
          行
        </label>
      </div>
      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th v-for="column in previewColumns" :key="column">{{ column }}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, rowIndex) in previewRows" :key="rowIndex">
              <td v-for="column in previewColumns" :key="column">{{ row[column] }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  </main>
</template>

<style scoped>
.page {
  margin: 0 auto;
  max-width: 960px;
  padding: 2rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

header h1 {
  margin: 0;
  font-size: 1.75rem;
}

header p {
  margin: 0.25rem 0 0;
  color: #666;
}

.status-card,
.uploader,
.stats,
.result {
  border: 1px solid #e0e0e0;
  border-radius: 12px;
  padding: 1.5rem;
  background: #fff;
  box-shadow: 0 15px 35px rgba(30, 60, 90, 0.05);
}

.status-row {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.label {
  color: #555;
}

.badge {
  padding: 0.4rem 0.8rem;
  border-radius: 999px;
  font-size: 0.9rem;
}

.badge.ok {
  background: #ecfdf3;
  color: #0a8c42;
}

.badge.pending {
  background: #fff6e6;
  color: #9c6b00;
}

.error {
  color: #c62828;
  margin-top: 1rem;
}

.hint {
  margin-top: 0.5rem;
  color: #555;
  font-size: 0.85rem;
  word-break: break-all;
}

.uploader.disabled {
  opacity: 0.6;
  pointer-events: none;
}

.drop-area {
  border: 2px dashed #a6b1c2;
  border-radius: 12px;
  padding: 2rem;
  text-align: center;
  display: block;
  cursor: pointer;
  color: #4d5b7c;
  transition: border-color 0.2s ease;
}

.drop-area:hover {
  border-color: #646cff;
}

.drop-area input {
  display: none;
}

.drop-content strong {
  display: block;
  font-size: 1.1rem;
  margin-bottom: 0.25rem;
}

.stats ul {
  list-style: none;
  padding: 0;
  margin: 0;
  display: grid;
  gap: 0.75rem;
}

.stats li {
  display: flex;
  justify-content: space-between;
  font-size: 1rem;
}

.stats span {
  color: #6b7280;
}

.result .table-wrapper {
  overflow: auto;
  max-height: 480px;
}

.pagination {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.75rem;
  margin-bottom: 0.5rem;
}

.pagination button {
  padding: 0.35rem 0.9rem;
  border-radius: 6px;
  border: 1px solid #cbd5f5;
  background: #f8f9ff;
  cursor: pointer;
  transition: background 0.2s ease;
}

.pagination button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.pagination select {
  margin-left: 0.35rem;
  border-radius: 4px;
  padding: 0.25rem 0.5rem;
  border: 1px solid #d1d5db;
}

.page-controls {
  display: flex;
  align-items: center;
  gap: 0.6rem;
  flex-wrap: wrap;
}

table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.9rem;
}

thead {
  position: sticky;
  top: 0;
  background: #f5f7fb;
}

th,
td {
  border-bottom: 1px solid #e5e7eb;
  padding: 0.5rem;
  text-align: left;
  white-space: nowrap;
}

tbody tr:nth-child(even) {
  background: #fafbff;
}
</style>
