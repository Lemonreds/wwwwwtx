<script setup>
import { ref } from 'vue'
import { onMounted } from 'vue';
// import { init } from 'excelize-wasm';

let excelize = null

onMounted(async() => {
     window.excelizeWASM.init('/excelize.wasm.gz')
      .then((excelize) => {
        // const f = excelize.NewFile();
        console.log(excelize)
      }, (err) => {
        console.log(err)
      });
})

</script>

<template>
HEELo
</template>

<style scoped>
.read-the-docs {
  color: #888;
}
</style>
